import { useState } from 'react';
import './App.css';
import Header from './components/Header';

function App() {

  const [names, setNames] = useState([
    'yasir',
    'Ali',
    'Shayan'
  ])

  return (
    <div className="App">
      <Header names={names} />
    </div>
  );
}

export default App;
