import React from 'react'

const Header = (props) => {

    return (
        <div><h1>This is a header component - {
            props.names.map(name => <p>{name}</p>)
        } </h1></div>
    )
}

export default Header